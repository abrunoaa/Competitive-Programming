#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 202020
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

int pd[101][101];

int ok(int a, int b){ return a > 0 && b > 0 && a != b; }

int solve(int i, int j){
	if(i > j) swap(i,j);
	if(pd[i][j] != -1) return pd[i][j];
	if(i == 1 && j == 2) return pd[i][j] = 0;
	char jav[305];
	clr(jav,0);
	rep(k,1,i+1) if(ok(i-k,j)) jav[solve(i-k,j)] = 1;
	rep(k,1,j+1) if(ok(i,j-k)) jav[solve(i,j-k)] = 1;
	rep(k,1,min(i,j)+1) if(ok(i-k,j-k)) jav[solve(i-k,j-k)] = 1;
	rep(k,0,305) if(!jav[k]) return pd[i][j] = k;
	assert(0);
	return -1;
}

int main(){
	clr(pd,-1);
	int n, ans = 0;
	scanf("%d", &n);
	rep(i,0,n){
		int a, b;
		scanf("%d%d", &a, &b);
		if(a==b){
			puts("Y");
			return 0;
		}
		ans ^= solve(a,b);
	}
	if(ans) puts("Y");
	else puts("N");
}

/*
2
1 3
2 3

1
1 2
*/
