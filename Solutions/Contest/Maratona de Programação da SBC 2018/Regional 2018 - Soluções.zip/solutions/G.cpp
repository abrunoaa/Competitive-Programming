#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 202020
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

typedef ll flowt;
flowt inf = 1e15;
namespace flow {
	const int M=202020,N=3030;
	int y[M],nxt[M],gap[N],fst[N],c[N],pre[N],q[N],dis[N];
	flowt f[M];
	int S,T,tot,Tn;
	void init(int s,int t,int tn) {
		tot=1; assert(tn<N && s < tn && t < tn);
		rep(i,0,tn) fst[i]=0;
		S=s;T=t;Tn=tn;
	}
	void add(int u,int v,flowt c1,flowt c2=0) {
		assert(u&&v);
		tot++;y[tot]=v;f[tot]=c1;nxt[tot]=fst[u];fst[u]=tot;
		tot++;y[tot]=u;f[tot]=c2;nxt[tot]=fst[v];fst[v]=tot;
	}
	flowt sap() {
		int u=S,t=1;flowt flow=0;
		rep(i,0,Tn) c[i]=fst[i],dis[i]=Tn,gap[i]=0;
		q[0]=T;dis[T]=0;pre[S]=0;
		rep(i,0,t) {
			int u=q[i];
			for (int j=fst[u];j;j=nxt[j]) if (dis[y[j]]>dis[u]+1&&f[j^1]) 
				q[t++]=y[j],dis[y[j]]=dis[u]+1;
		}
		rep(i,0,Tn) gap[dis[i]]++;
		while (dis[S]<=Tn) {
			while (c[u]&&(!f[c[u]]||dis[y[c[u]]]+1!=dis[u])) c[u]=nxt[c[u]];
			if (c[u]) {
				pre[y[c[u]]]=c[u]^1;
				u=y[c[u]];
				if (u==T) {
					flowt minf=inf;
					for (int p=pre[T];p;p=pre[y[p]]) minf=min(minf,f[p^1]);
					for (int p=pre[T];p;p=pre[y[p]]) f[p^1]-=minf,f[p]+=minf;
					flow+=minf;u=S;
				}
			} else {
				if (!(--gap[dis[u]])) break;
				int mind=Tn;
				c[u]=fst[u];
				for (int j=fst[u];j;j=nxt[j]) if (f[j]&&dis[y[j]]<mind) 
					mind=dis[y[j]],c[u]=j;
				dis[u]=mind+1;
				gap[dis[u]]++;
				if (u!=S) u=y[pre[u]];
			}
		}
		return flow;
	}
};

int a, b, m, va[MAXN], vb[MAXN];
pair<int,pii> ar[MAXN];

ll sum;

bool bb(int k){
	int N = a+b+5, s = a+b+2, t = a+b+3;
	flow::init(s,t,N);
	rep(i,0,a) flow::add(i+1, t, va[i]);
	rep(i,0,b) flow::add(s,i+a+1,vb[i]);
	rep(i,0,k+1) flow::add(1+a+ar[i].y.y, 1+ar[i].y.x, 1e11);
	ll val = flow::sap();
	return val == sum;
}

int main(){
	scanf("%d%d%d", &a, &b, &m);
	rep(i,0,a) scanf("%d", va+i), sum += va[i];
	rep(i,0,b) scanf("%d", vb+i);
	rep(i,0,m) scanf("%d%d%d", &ar[i].y.x, &ar[i].y.y, &ar[i].x), ar[i].y.x--, ar[i].y.y--;
	sort(ar,ar+m);
	int l = 0, r = m-1, ans = -1;
	while(l <= r){
		int mid = (l+r)>>1;
		if(bb(mid)){
			ans = ar[mid].x;
			r = mid-1;
		}else l = mid+1;
	}
	printf("%d\n", ans);
}
/*
3 2 5
20 10 10
30 20
1 1 2
2 1 1
2 2 3
3 1 4
3 2 5

3 2 5
20 10 10
25 30
1 1 3
2 1 1
2 2 4
3 1 2
3 2 5

4 3 9
10 10 10 20
10 15 30
1 1 1
1 2 1
2 1 3
2 2 2
3 1 10
3 2 10
4 1 1
4 2 2
4 3 30

1 2 2
40
30 10
1 1 100
1 2 200
*/
