#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 2002
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

typedef bitset<MAXN> vld;

vld fat_lu(vector<vld > &U, vld b){
	int n = sz(U);
	int l = 0;
	vi linha(n,-1);
	rep(c,0,n){
		int r = l;
		if(U[l][c] == 0) rep(i,l+1,n)
			if(U[i][c]){
				r = i;
				break;
			}
		if(l!=r){
			swap(U[l], U[r]);
			int t = b[l];
			b[l] = b[r];
			b[r] = t;
		}
		if(!U[l][c]) continue;
		linha[c] = l;
		rep(i,l+1,n) if(U[i][c]){
			U[i] ^= U[l];
			b[i] = b[i]^b[l];
		}
		l++;
	}
	rep(i,0,n) if(U[i].count() == 0 && b[i])
		{ puts("impossible"); exit(0); }
	vld x;
	dec(i,n-1,0){
		if(linha[i] == -1) x[i] = 1;
		else x[i] = b[linha[i]];
		if(x[i]) rep(j,0,i) if(U[j][i]) b[j] = b[j]^1;
	}
	return x;
}

int n, m;
vector<vld> mat;
vld x;

int main(){
	scanf("%d%d", &m, &n);
	mat.resize(max(m,n));
	rep(i,0,m){
		scanf(" %*c");
		int v = 1;
		while(1){
			char c;
			scanf(" %c", &c);
			if(c == 'n') scanf("%*c %*c %*c"), v ^= 1;
			int d;
			scanf("%d", &d);
			d--;
			mat[i][n-1-d] = mat[i][n-1-d] ^ 1;
			scanf(" %c", &c);
			if(c == 'o') scanf("%*c");
			else break;
		}
		if(i+1<m) scanf(" %*c %*c %*c ");
		if(v) x.set(i);
	}
	x = fat_lu(mat, x);
	rep(i,0,n) if(x[n-1-i]) printf("T"); else printf("F");
	printf("\n");
}

/*

4 3
(x1 or x2 or x3) and
(not x1) and
(x1 or not x2 or x3) and
(x2 or not x3)

5 6
(not x1) and
(x1 or x2 or x4) and
(x1 or x3 or x5) and
(not x2 or x3 or x5) and
(x2 or x3 or not x4)

1 1
(x1 or x1 or not x1)

1 4
(x1 or x3)

*/
