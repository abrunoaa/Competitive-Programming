#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 101010
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

void comprime(int * v, int n){
	static int aux[MAXN];
	rep(i,0,n) aux[i] = v[i];
	sort(aux,aux+n);
	rep(i,0,n) v[i] = lower_bound(aux,aux+n,v[i])-aux;
}

int bit[MAXN];

void upd(int p, int v){for(p++;p<MAXN; p+=p&-p) bit[p]+=v;}
int query(int p){int ret=0;for(p++;p>0;p-=p&-p) ret+=bit[p]; return ret;}

ll count(int * u, int * v, int n){
	static pii vet[MAXN];
	rep(i,0,n) vet[i] = mp(u[i],v[i]);
	sort(vet,vet+n);
	rep(i,0,MAXN) bit[i] = 0;
	ll ret = 0;
	rep(i,0,n){
		ret += i-query(vet[i].y);
		upd(vet[i].y,1);
	}
	return ret;
}

int n, m, va[MAXN], vb[MAXN];

int main(){
	scanf("%*d%*d");
	scanf("%d%d", &n, &m);
	rep(i,0,n) scanf("%d%d", va+i, vb+i);
	ll ans = 1;
	comprime(va,n);
	comprime(vb,n);
	ans += count(va,vb,n);
	rep(i,0,n) ans += 1;
	rep(i,0,m) scanf("%d%d", va+i, vb+i);
	comprime(va,m);
	comprime(vb,m);
	ans += count(va,vb,m);
	rep(i,0,m) ans += 1+n;
	printf("%lld\n", ans);
}

