#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 202020
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

int n, pd[1<<10][1010];
vector<pair<pii,pii> > vet;
vi pr;

int solve(int mask, int cur){
	if(cur == sz(vet)){
		if(mask == (1<<n)-1) return 0;
		return -1e9;
	}
	int & ret = pd[mask][cur];
	if(ret != -1) return ret;
	ret = max(solve(mask, cur+1), solve(mask|(1<<vet[cur].y.y), pr[cur]) + vet[cur].y.x);
	return ret;
}

int main(){
	clr(pd,-1);
	scanf("%d", &n);
	rep(i,0,n){
		int q;
		scanf("%d", &q);
		rep(j,0,q){
			int l, r, o;
			scanf("%d%d%d", &l, &r, &o);
			vet.pb(mp(mp(l,r),mp(o,i)));
		}
	}
	sort(all(vet));
	pr.resize(sz(vet),sz(vet));
	rep(i,0,sz(vet)) rep(j,i,sz(vet)) if(vet[i].x.y <= vet[j].x.x){
		pr[i] = j;
		break;
	}
	printf("%d\n", max(solve(0,0),-1));
}
/*
3
4 1 10 100 20 30 90 40 50 95 80 100 90
1 40 50 13
2 9 29 231 30 40 525
*/
