#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 101010
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

#include<dirent.h>

char dirName[500], fileInput[500], fileOutput[500], command1[500], command2[500];

int main(){
	for(char problem = 'A'; problem <= 'M'; problem++){
		
		sprintf(dirName, "../contest_tests/%c/input", problem);
		DIR *dir = opendir(dirName);
		struct dirent *entry;
		int qtTests = 0;
		while ((entry = readdir(dir)) != NULL) {
			if(entry->d_type != DT_DIR) {
				qtTests++;
			}
		}
		closedir(dir);
		
		ld tempo = 0;
		for(int test = 1; test <= qtTests; test++){
			sprintf(fileInput, "../contest_tests/%c/input/%c_%d", problem, problem, test);
			sprintf(fileOutput, "../contest_tests/%c/output/%c_%d", problem, problem, test);
			sprintf(command1, "./%c < %s > aux", problem, fileInput);
			sprintf(command2, "diff aux %s | head -6", fileOutput);
			auto start = std::chrono::steady_clock::now();
			system(command1);
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds> 
                            (std::chrono::steady_clock::now() - start);
			tempo = max(tempo, (ld)duration.count()/1000);
			system(command2);
			printf("Problem %c test %d\n", problem, test);
		}
		printf("Problem %c : %d tests %.3fs\n", problem, qtTests, tempo);
	}
	system("rm aux");
}

