#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 202020
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

struct circle{
	ld x, y, r;
	bool operator<(circle b) const{
		return r < b.r;
	}
}vet[MAXN];

vi adj[MAXN];
int n, ans;

bool tem_inter(circle a, circle b){
	if(a.r < b.r) swap(a,b);
	return a.r < b.r + hypotl(a.x-b.x, a.y-b.y);
}

void dfs(int nv, int v){
	if(!tem_inter(vet[nv],vet[v])) return;
	ans += 2;
	if(ans > 2*n){
		puts("greater");
		exit(0);
	}
	for(int u : adj[v]) dfs(nv, u);
}

int main(){
	scanf("%d", &n);
	rep(i,0,n) scanf("%lf%lf%lf", &vet[i].x, &vet[i].y, &vet[i].r);
	sort(vet,vet+n);
	set<int> roots;
	rep(i,0,n){
		for(int id : roots){
			if(tem_inter(vet[i], vet[id]))
				dfs(i, id);
			else adj[i].pb(id);
		}
		for(int id : adj[i])
			roots.erase(id);
		roots.insert(i);
	}
	printf("%d\n", ans);
}

/*

6
0.00 1.00 4.00
0.00 0.00 10.500
4.00 0.00 6.00
1.00 1.00 1.750
-1.00 -1.00 8.000
2.00 -2.00 4.00

4
-1.00 -1.00 3.00
1.00 -1.00 3.001
-3.004 3.003 5.002
1.00 1.00 3.005

*/
