#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 202020
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

int n, k, x[111], y[111];
ld INF = 1e20, pd[111][1<<11], ans;

ld dist(int i, int j){
	return hypotl(x[i]-x[j], y[i]-y[j]);
}

int main(){
	ans = INF;	
	rep(i,0,111) rep(j,0,1<<11) pd[i][j] = INF;
	scanf("%d%d", &n, &k);
	rep(i,0,n) scanf("%d%d", x+i, y+i);
	rep(i,0,k) rep(j,k,n) pd[j][1<<i] = dist(i,j);
	rep(mask,1,1<<k) rep(i,k,n){
		for(int sub = mask; sub > 0; sub = (sub-1)&mask)
			pd[i][mask] = min(pd[i][mask], pd[i][sub] + pd[i][mask^sub]);
		rep(j,k,n) pd[j][mask] = min(pd[j][mask], pd[i][mask] + dist(i,j));
		if(mask == (1<<k)-1) ans = min(ans, pd[i][mask]);
	}
	printf("%.5lf\n", ans);
}
/*
6 4
-20 10
-20 -10
20 10
20 -10
-10 0
10 0

22 9
-3 -25
0 -6
-1 -9
2 -21
-5 -19
0 -23
-2 24
-4 37
-3 33
-3 -12
2 39
3 -49
-3 -26
2 24
5 3
-4 -9
-2 -9
-4 8
3 -33
-2 31
-1 -13
0 2

*/
