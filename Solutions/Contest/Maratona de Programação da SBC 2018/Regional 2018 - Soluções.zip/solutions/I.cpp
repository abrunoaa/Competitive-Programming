#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 202020
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

bitset<1010> vet, inte[1010], cc;
int n, m;

int main(){
	scanf("%d%d", &n, &m);
	int l;
	scanf("%d", &l);
	rep(i,0,l){
		int p;
		scanf("%d", &p);
		vet.set(p-1);
	}
	rep(i,0,n){
		int k;
		scanf("%d", &k);
		rep(j,0,k){
			int v;
			scanf("%d", &v);
			inte[i].set(v-1);
		}
	}
	cc.reset();
	rep(i,0,2*n){
		cc ^= inte[i%n];
		if(cc == vet){
			printf("%d\n", i+1);
			return 0;
		}
	}
	puts("-1");
}
