#include <bits/stdc++.h>
using namespace std;
#define mp make_pair
#define pb emplace_back
#define x first
#define y second
#define sz(a) ((int)(a).size())
#define rep(i,a,b) for(auto i=(a); i<(b); i++)
#define dec(i,n,a) for(auto i=(n); i>=(a); i--)
#define clr(a,v) memset(a, v, sizeof(a))
#define all(a) (a).begin(),(a).end()
#define EPS 3e-8
#define fcin ios_base::sync_with_stdio(false)
#define db(x) cerr << #x << " == " << x << endl
#define _ << " " <<
#define MAXN 101010
#define LOGN 20
typedef long long ll;
typedef double ld;
typedef pair<int,int> pii;
typedef vector<int> vi;

vector <int> adj[MAXN];
char base[MAXN];
int ptr;
int cnum, cid[MAXN], chead[MAXN], posb[MAXN], nodeb[MAXN];
int nvl[MAXN], anc[MAXN][LOGN], tam[MAXN];

char pat[103], tex[MAXN];
int patLen;

int F[MAXN];

void kmpPreprocess() {
	int i = 0, j = -1;
	F[0] = -1;
	while(i < patLen) {
		while(j >= 0 && pat[i] != pat[j]) j = F[j];
		F[++i] = ++j;
	}
}

pii anda(int j, char c){
	while(j >= 0 && c != pat[j]) j = F[j];
	j++;
	int qt = 0;
	if(j == patLen) {
		qt++;
		j = F[j];
	}
	return mp(j, qt);
}

struct Node{
	pii res[103];
	Node(){
		for(int i = 0; i < patLen; i++)
			res[i] = mp(i,0);
	}
	void reset(char c){
		for(int i = 0; i < patLen; i++)
			res[i] = anda(i, c);
	}
	pii & operator[](int id){ return res[id]; }
} st1[MAXN<<2], st2[MAXN<<2];

Node merge(Node a, Node b){
	Node c;
	rep(i,0,patLen) c[i] = mp(b[a[i].x].x, a[i].y + b[a[i].x].y);
	return c;
}

void build_tree(int b, int l, int r){
	if(l==r){
		st1[b].reset(base[l]);
		st2[b].reset(base[l]);
		return;
	}
	int fe = b<<1, fd = fe|1, mid = (l+r)>>1;
	build_tree(fe, l, mid);
	build_tree(fd, mid+1, r);
	st1[b] = merge(st1[fe], st1[fd]);
	st2[b] = merge(st2[fd], st2[fe]);
}

void upd_tree(int b, int l, int r, int p, char v){
	if(r < p || p < l) return;
	if(l == r){
		st1[b].reset(v);
		st2[b].reset(v);
		return;
	}
	int fe = b<<1, fd = fe|1, mid = (l+r)>>1;
	upd_tree(fe, l, mid, p, v);
	upd_tree(fd, mid+1, r, p, v);
	st1[b] = merge(st1[fe], st1[fd]);
	st2[b] = merge(st2[fd], st2[fe]);
}

Node query_tree(int b, int l, int r, int x, int y, bool inve){
	if(y < l || r < x) return Node();
	if(x <= l && r <= y){
		if(inve) return st2[b];
		return st1[b];
	}
	int fe = b<<1, fd = fe|1, mid = (l+r)>>1;
	if(inve)
		return merge(query_tree(fd, mid+1, r, x, y, inve), query_tree(fe, l, mid, x, y, inve));
	return merge(query_tree(fe, l, mid, x, y, inve), query_tree(fd, mid+1, r, x, y, inve));
}

Node query_up(int u, int v, bool inve) {
	int cu, cv = cid[v];
	Node ret;
	while(1){
		cu = cid[u];
		if(cu == cv){
			if(inve)
				ret = merge(ret, query_tree(1, 0, ptr-1, posb[v], posb[u], inve));
			else
				ret = merge(query_tree(1, 0, ptr-1, posb[v], posb[u], inve), ret);
			break;
		}
		if(inve)
			ret = merge(ret, query_tree(1, 0, ptr-1, posb[chead[cu]], posb[u], inve));
		else
			ret = merge(query_tree(1, 0, ptr-1, posb[chead[cu]], posb[u], inve), ret);
		u = chead[cu];
		u = anc[u][0];
	}
	return ret;
}

int LCA(int u, int v) {
	if(nvl[u] < nvl[v]) swap(u,v);
	int diff = nvl[u] - nvl[v];
	dec(i,LOGN-1,0) if((1<<i) <= diff) u = anc[u][i], diff -= (1<<i);
	if(u == v) return u;
	dec(i,LOGN-1,0) if(anc[u][i] != anc[v][i]) {
		u = anc[u][i];
		v = anc[v][i];
	}
	return anc[u][0];
}

int sobe(int v, int diff){
	rep(i,0,LOGN) if(diff&(1<<i)) v = anc[v][i];
	return v;
}

int query(int u, int v) {
	char mudou = 0;
	if(nvl[u] < nvl[v]) swap(u, v), mudou = 1;
	int lca = LCA(u, v);
	if(lca == v)
		return query_up(u, v, !mudou)[0].y;
	if(mudou) swap(u,v);
	int aux = sobe(u, nvl[u] - nvl[lca] - 1);
	return merge(query_up(u, aux, 1), query_up(v, lca, 0))[0].y;
}

void HLD(int v, int pr) {
	if(chead[cnum] == -1)
		chead[cnum] = v;

	cid[v] = cnum;
	posb[v] = ptr;
	nodeb[ptr] = v;
	base[ptr++] = tex[v];

	int best = -1;
	rep(i,0,sz(adj[v])) if(adj[v][i] != pr)
		if(best == -1 || tam[best] < tam[adj[v][i]])
			best = adj[v][i];

	if(best != -1)
		HLD(best, v);

	rep(i,0,sz(adj[v]))
		if(adj[v][i] != pr && adj[v][i] != best) {
			cnum++;
			HLD(adj[v][i], v);
		}
}

void dfs(int v, int pr) {
	tam[v] = 1;
	rep(i,0,sz(adj[v]))
		if(adj[v][i] != pr) {
			int u = adj[v][i];
			nvl[u] = nvl[v] + 1;
			anc[u][0] = v;
			rep(j,1,LOGN) anc[u][j] = anc[anc[u][j-1]][j-1];
			dfs(u, v);
			tam[v] += tam[u];
		}
}

int n, q;
char aux[MAXN];

int main(){
	clr(chead,-1);
	scanf("%d%d", &n, &q);
	scanf("%s", pat);
	patLen = strlen(pat);
	scanf("%s", tex);
	rep(i,1,n){
		int u, v;
		scanf("%d%d", &u, &v);
		u--, v--;
		adj[u].pb(v);
		adj[v].pb(u);
	}
	
	kmpPreprocess();
	dfs(0,0);
	HLD(0,0);
	build_tree(1, 0, ptr-1);
	
	while(q--){
		int tp;
		scanf("%d", &tp);
		if(tp==1){
			int u, v;
			scanf("%d%d", &u, &v);
			u--, v--;
			printf("%d\n", query(u,v));
		}else{
			int v;
			char c;
			scanf("%d %c", &v, &c);
			v--;
			upd_tree(1, 0, ptr-1, posb[v], c);
		}
	}
}
/*
4 4
xtc
xtzy
1 2
2 3
3 4
1 1 3
2 3 c
1 1 3
1 3 1

6 7
lol
dlorlx
1 2
1 3
3 4
3 5
5 6
1 2 6
2 3 l
2 6 l
2 5 o
1 2 6
2 1 o
1 6 2

5 2
aba
ababa
1 2
2 3
3 4
4 5
1 1 5
1 5 1

7 2
DEF
EDFBCGA
1 2
1 3
2 4
2 5
4 7
3 6
1 2 3
1 3 2
*/
